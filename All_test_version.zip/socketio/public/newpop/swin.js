var url = "./showALL.html"


function openWin() {
    window.open(url, "taco", "width=800,height=600");
}
