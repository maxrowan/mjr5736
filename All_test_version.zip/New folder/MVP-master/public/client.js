let map;
let inclementTweets = [],    // rgba( 0, 255, 0, 1)
    rainTweets = [],         // rgba( 255, 165, 0, 1)
    snowTweets = [],         // rgba( 0, 255, 255, 1)
    hailTweets = [],         // rgba( 219, 112, 147, 1)
    windTweets = [],         // rgba( 255, 20, 147, 1)
    iceTweets = [],          // rgba( 139, 0, 139, 1)
    fireTweets = [];         // rgba( 233, 150, 122, 1)
let live = true,
    inclement = true,
    rain = true,
    snow = true,
    hail = true,
    wind = true,
    ice = true,
    fire = true;

// initialize map
function initMap() {

    /* google map */
    let erieInsurance = { lat: 42.130601, lng: -80.083889 };
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 6,
        center: erieInsurance,
        gestureHandling: 'greedy'
    });

    retrieveFromDB();
}

let socket = io();

/**
 * add point to array and show it on map when it's received from the server
 */
socket.on('tweetEvent', function( tweet ) {
    if ( live )
        showTweet( tweet, 'tweet-content-body' );
});

socket.on( 'getAllTweets', function( tweets ) {
    showAllTweets( tweets );
});

function showAllTweets( tweets ) {
    for ( let i = 0; i < tweets.length; i++ ) {
        showTweet( tweets[i], 'tweet-content-body' );
    }
}

function addToMap( tweet, color ) {
    let marker = setMarker( tweet.geoPoint, color );
    addToList( tweet.NLUEntity, marker );
}

function addToList( entity, marker ) {
    switch ( entity ) {
        case "INCLEMENT_WEATHER":
            inclementTweets.push( marker );
            break;
        case "RAIN" :
            rainTweets.push( marker );
            break;
        case "SNOW" :
            snowTweets.push( marker );
            break;
        case "HAIL" :
            hailTweets.push( marker );
            break;
        case "WIND" :
            windTweets.push( marker );
            break;
        case "ICE" :
            iceTweets.push( marker );
            break;
        case "FIRE":
            fireTweets.push( marker );
    }
}

function setMarker( geoPoint, color ) {

    let mapIcon = {
        path: google.maps.SymbolPath.CIRCLE,
        fillColor: color,
        fillOpacity: 0.5,
        scale: 10,
        strokeColor: 'white',
        strokeWeight: 1
    };

    return new google.maps.Marker({
        position: {
            lat: geoPoint.lat,
            lng: geoPoint.lng
        },
        icon: mapIcon,
        map: map
    });
}

function addToSidebar( tweet, color ) {

    let image = addImage( tweet );
    let user = tweet.user;

    let profilePic = user.profile_image_url;
    let name = user.name;
    let handle = user.screen_name;
    let header = addHeader( profilePic, name, handle );

    let text = tweet.text;

    document.getElementById( 'tweet-list' ).innerHTML +=
        '<li class="list-group-item p-0 ">' +
            '<div class="card unhighlighted"  onclick=highlight(this) style="border-left: 4px solid' + color +'">' +
            //<!-- Tweet Image -->
            image +
           // <!-- Tweet Text Content -->
            '<div class="card-body">' +
               // <!-- Header -->
                header +
               // <!--Text-->
                '<p class="card-text">' + text + ' </p>' +
                '</div>' +
            '</div>' +
        '</li>';
}

function addImage() {
    return '';//'<img class="img-fluid" src="https://mdbootstrap.com/img/Photos/Others/images/43.jpg" alt="Card image cap">';
}

function addHeader( profilePic, name, handle ) {

    let header =
        '<div class="card-title">' +
            '<div class="row pl-3">' +
                '<img src="' + profilePic + '" onerror="this.src=\'https://abs.twimg.com/sticky/default_profile_images/default_profile_bigger.png\';" alt class="profile-pic mr-2" >' +
                '<div>' +
                    '<div class="twitter-name mb-0"><strong>' + name + '</strong></div>' +
                    '<div class="twitter-handle">' + '@' + handle + '</div>' +
                '</div>' +
            '</div>' +
        '</div>';

    return header;
}


function getColor( entity ) {
    switch ( entity ) {
        case "INCLEMENT_WEATHER":
            return '#76ff03';
        case "RAIN" :
            return '#ff9800';
        case "SNOW" :
            return '#2962ff';
        case "HAIL" :
            return '#9c27b0';
        case "WIND" :
            return '#ffff00';
        case "ICE" :
            return '#18ffff';
        case "FIRE":
            return '#f44336';
    }
}

function showTweet( tweet ) {
    let color = getColor( tweet.NLUEntity );
    addToMap( tweet, color );
    addToSidebar( tweet, color );
}

function stopStream() {
    socket.emit( 'stopStream' );
}

function startStream() {
    socket.emit( 'startStream' );
}

function retrieveFromDB () {

    // remove data from real-time sidebar
    document.getElementById( 'tweet-list' ).innerHTML = '';

    // remove data from all heatmaps
    clearMarkers();

    // tell server to retrieve and send all tweets from DB
    socket.emit( 'retrieveAll' );
}

function clearAllTweets() {
    document.getElementById( 'tweet-list' ).innerHTML = '';

    clearMarkers();
}

function clearMarkers() {
    setMap( inclementTweets, null );
    setMap( rainTweets, null );
    setMap( snowTweets, null );
    setMap( hailTweets, null );
    setMap( windTweets, null );
    setMap( iceTweets, null );
    setMap( fireTweets, null );
}

function setMap( markers, map) {
    for ( let i = 0; i < markers.length; i++) {
        markers[i].setMap( map );
    }
}

/** button functions **/
function setLive() {
    live = !live;
}
function setInclement() {
    inclement = !inclement;
    setMap( inclementTweets, inclement ? map : null );
}
function setRain() {
    rain = !rain;
    setMap( rainTweets, rain ? map : null );
}
function setSnow() {
    snow = !snow;
    setMap( snowTweets, snow ? map : null );
}
function setHail() {
    hail = !hail;
    setMap( hailTweets, hail ? map : null );
}
function setWind() {
    wind = !wind;
    setMap( windTweets, wind ? map : null );
}
function setIce() {
    ice = !ice;
    setMap( iceTweets, ice ? map : null );
}
function setFire() {
    fire = !fire;
    setMap( fireTweets, fire ? map : null );
}

//change color 
function highlight(row)
{
  
  if($(row).hasClass('unhighlighted'))
  {  alert("Fuk this ");
      $(row).removeClass('unhighlighted').addClass('highlighted');
     /* var e =$("#geo_coord",row).text();
      // dotting
      var split = e.split(',');
      var coord = {'lat':split[0],'lng':split[1]}
      */

  }
  else if($(row).hasClass('highlighted')) 
  {
    $(row).removeClass('highlighted').addClass('unhighlighted');
    /*
    var e =$("#geo_coord",row).text();
    var split = e.split(',');
    var coord = {'lat':split[0],'lng':split[1]}
    */
  }
}
function filter()
{   //temp View
    tempView = [];

    // Save only ture 
    (rain) ?  tempView.push(rainTweets): "false "
    (snow) ?   tempView.push(snowTweets): "false "
    (hail) ?  tempView.push(hailTweets): "true "
    (wind) ? tempView.push(windTweets): "true "
    (ice) ?  tempView.push(iceTweets): "true "
    (fire) ?  tempView.push(fireTweets): "true "
    
    // need function to hide all 

    
  
}

function getData()
{ 

    var myObj = { "name":"test"};
    var myJSON = JSON.stringify(myObj);
    return $.ajax
        ({
            url: "/receiveData",
            type: "POST",
            contentType: "application/json; charset=UTF-8",
            data:myJSON,
            dataType: "json",
            success: handledata
        });
}
function handledata(data)
{
    console.log(data);
}