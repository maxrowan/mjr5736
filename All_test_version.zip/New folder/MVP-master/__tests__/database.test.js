// import database module
const db = require( '../scripts/database' );

