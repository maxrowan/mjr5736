var point_dot = [];
function getData()
{ 
   var taco = window.opener.document.getElementById('dbser').value;
    var myObj = { "name":taco};
    var myJSON = JSON.stringify(myObj);
    return $.ajax
        ({
            url: "/receiveData",
            type: "POST",
            contentType: "application/json; charset=UTF-8",
            data:myJSON,
            dataType: "json",
            success: handledata
        });
}
function handledata(data)
{   //user  
        //data[0].user.name
    //twmsg
        //data[0].text
    //data written at
        //data[0].created_at + data[0].user.location
    // geo loca
        //data[0].coordinates
   for(i = 0; i < data.length;i++)
   {
    $('#dbData tr:last').after('<tr class = unhighlighted onclick=highlight(this)>'+
     '<td>'+ data[i].user.name + '</td>'+
     '<td id ="tw_loc">'+ data[i].user.location + '</td>'+
     '<td>'+ data[i].text + '</td>'+
     '<td id = "tw_written">'+ data[i].created_at + '</td>'+
     '<td id = "geo_coord">'+ data[i].coordinates.coordinates + '</td>'
     )
     
   }
    
    
}

//change color 
function highlight(row)
{
  
  if($(row).hasClass('unhighlighted'))
  {  
      $(row).removeClass('unhighlighted').addClass('highlighted');
      var e =$("#geo_coord",row).text();
      // dotting
      var split = e.split(',');
      var coord = {'lat':split[0],'lng':split[1]}
      window.opener.dotPoint(coord);

  }
  else if($(row).hasClass('highlighted')) 
  {
    $(row).removeClass('highlighted').addClass('unhighlighted');
    var e =$("#geo_coord",row).text();
    var split = e.split(',');
    var coord = {'lat':split[0],'lng':split[1]}
    window.opener.removeDot(coord);
  
  }
}
function filter()
{

  
 $('tr').each(function(i)
 {  
     if(i !=0)
     {
      input = document.getElementById("state").value.toUpperCase();
      var check = $("#tw_loc",this).text().toUpperCase();
       if(check.indexOf(input) > -1)
       {
          console.log($("#tw_loc",this).text());
       }
     }
    
  })
}
function filterView(x)
{
  var input;
      table = document.getElementById("dbData");
      tr = table.getElementsByTagName("tr");
    switch(x)
    {case 1:
      input = document.getElementById("state");
      break;
      case 2:
      input = document.getElementById("weather");
      break;
      case 3:
      input= document.getElementById("year");
      break;
      
    } 
      filter = input.value;
      
      for(i = 1; i < tr.length; i++)
      {
        td = tr[i].getElementsByTagName("td")[x];
        //td2 = tr[i].getElementsByTagName("td")[2];
        //td3 = tr[i].getElementsByTagName("td")[3];
        if (td) 
        {
            if(td.innerHTML.indexOf(filter) > -1) 
            {
             tr[i].style.display = "";
          
             
            }
              else 
            {
              tr[i].style.display = "none";
            }
        }    
      }
    
 }