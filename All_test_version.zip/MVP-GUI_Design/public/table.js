
  //change color 
  function highlight(row)
  {
    
    if($(row).hasClass('unhighlighted'))
    {  
        $(row).removeClass('unhighlighted').addClass('highlighted');
        var e =$("#geo_coord",row).text();
        var split = e.split(',');
        console.log(split[0]);
        console.log(split[1]);
       // var obj = {'lat':}
        // dotting
        //point_dot.push(obj);
        window.opener.point_dot= point_dot;
        window.opener.dotPoint();
     //   console.log(point_dot + "this is child");
      //  console.log(window.opener.point_dot + "this is parent");
    }
    else if($(row).hasClass('highlighted')) 
    {
      $(row).removeClass('highlighted').addClass('unhighlighted');
      var e =$("#geo_coord",row).text();
      point_dot.pop("{"+e+"}");
      window.opener.point_dot= point_dot;
      window.opener.dotPoint();
    
    }
  }